#!/bin/bash

PROJECT_ROOT=`git rev-parse --show-toplevel`

cd $PROJECT_ROOT
. venv/bin/activate

if [ -z "$*" ]
then
    invoke --list
else
    invoke $@
fi
