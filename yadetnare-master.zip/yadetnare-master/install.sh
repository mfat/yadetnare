#!/bin/bash

# install pyenv-3.4 on old systems
# http://askubuntu.com/a/290283/361969

die(){
    echo "ERROR"
    rm -rf ../venv
    exit 1
}

sudo apt-get install libjpeg-dev libfreetype6-dev zlib1g-dev libpng12-dev python3.4-dev rabbitmq-server libmysqlclient-dev mysql-server

if [ ! -d venv ]
then
    pyvenv-3.4 venv --without-pip || die
    . venv/bin/activate
    cd venv
    wget https://bootstrap.pypa.io/get-pip.py || die
    python get-pip.py || die
    cd ..
fi

. venv/bin/activate
pip install -r requirements.txt
