#!/usr/bin/env python3

import os
from invoke import task
from invoke import run

PROJECT_ROOT =  run("git rev-parse --show-toplevel", hide="out").stdout.strip()

@task
def collectstatic(silent=False):
    arg = ""
    if silent:
        arg = "-v 0"

    os.makedirs(os.path.join(PROJECT_ROOT, "todo/STATIC"), exist_ok=True)
    run("cd %s/todo && python manage.py collectstatic  -c --noinput %s" % (PROJECT_ROOT, arg))

'''
development commands

# create superuser
./task.sh createsuperuser --local
'''

@task
def run_celery():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "todo.settings")
    try:
        run("cd %s/todo && celery -B -A todo worker -l info" % PROJECT_ROOT)
    except KeyboardInterrupt:
        pass

@task
def run_site():
    run("cd %s/todo && python manage.py migrate" % PROJECT_ROOT)
    run("cd %s/todo && python manage.py runserver 0.0.0.0:8000" % PROJECT_ROOT)

@task
def locale():
    run("cd %s/todo/todo_api && python ../manage.py makemessages -a" % PROJECT_ROOT)
    run("cd %s/todo/todo_api && python ../manage.py compilemessages" % PROJECT_ROOT)

'''
production commands

# run api and server
./tasks.sh deploy_site

# run celery daemon
./tasks.sh deploy_celery

# create superuser
./task.sh createsuperuser
'''

@task
def deploy_site(pre=[collectstatic,]):
    run("sudo cp %s/nginx.conf /etc/nginx/sites-enabled/todo" % PROJECT_ROOT)
    run('sudo sed -i -e "s@PROJECT_ROOT@%s@g" /etc/nginx/sites-enabled/todo' % PROJECT_ROOT)
    run("sudo service nginx reload")

    run("cd %s/todo && python manage.py migrate --settings todo.deploy" % PROJECT_ROOT)

    try:
        run("cd %s/todo && gunicorn todo.wsgi -c todo/gunicorn.py" % PROJECT_ROOT)
    except KeyboardInterrupt:
        pass

@task
def deploy_celery():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "todo.deploy")
    try:
        run("cd %s/todo && celery -B -A todo worker -l info -f celery.log" % PROJECT_ROOT)
    except KeyboardInterrupt:
        pass

@task
def createsuperuser(local=False):
    if local:
        os.environ.setdefault("DJANGO_SETTINGS_MODULE", "todo.settings")
    else:
        os.environ.setdefault("DJANGO_SETTINGS_MODULE", "todo.deploy")

    run("cd %s/todo && python manage.py createsuperuser" % PROJECT_ROOT)
