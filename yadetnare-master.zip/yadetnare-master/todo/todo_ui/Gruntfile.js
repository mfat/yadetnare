module.exports = function(grunt) {

    // Project configuration.
    grunt.initConfig({

        pkg: grunt.file.readJSON('package.json'),

        wiredep: {
            rtl: {
                // Point to the files that should be updated when
                // you run `grunt wiredep`
                src: [
                    'index.html' // .html support...
                ],
                dependencies: true,
                devDependencies: false,
                exclude: ['lib/ionrangeslider/css/ion.rangeSlider.skinSimple.css',
                    'lib/ionrangeslider/css/ion.rangeSlider.skinFlat.css'
                ],
                fileTypes: {
                    html: {
                        block: /(([ \t]*)<!--\s*bower:*(\S*)\s*-->)(\n|\r|.)*?(<!--\s*endbower\s*-->)/gi,
                        detect: {
                            js: /<script.*src=['"](.+)['"]>/gi,
                            css: /<link.*href=['"](.+)['"]/gi
                        },
                        replace: {
                            js: '<script src="/{{filePath}}"></script>',
                            css: '<link rel="stylesheet" href="/{{filePath}}" />'
                        }
                    }
                }
            }
        },
        "bower-install-simple": {
            options: {
                color: true,
                directory: "lib"
            },
            "prod": {
                options: {
                    production: true
                }
            },
            "dev": {
                options: {
                    production: false
                }
            }
        },
        sass: { // task
            dist: { // target
                files: { // dictionary of files
                    'static/css/main.css': 'dev/css/main.sass' // 'destination': 'source'
                },
                options: { // dictionary of render options
                    outputStyle: "compressed"
                }
            }
        },
        cssmin: {
            main: {
                files: [{
                    expand: true,
                    cwd: 'static/css',
                    src: ['*.css'],
                    dest: 'static/css'
                }]
            }

        },

        uglify: {
            development: {
                options: {
                    /*apply if you want to prevent changes to your variable and function names.
          mangle: false
          */
                    mangle: false
                },
                files: [{
                    expand: true,
                    cwd: 'static/js',
                    src: ['*.js'],
                    dest: 'static/js'
                }]
            }
        },


        htmlmin: { // Task
            production: { // Target
                options: { // Target options
                    removeComments: true,
                    collapseWhitespace: true,
                    maxLineLength: 200
                },
                files: { // Dictionary of files
                    'static/index.html': 'static/index.html'
                }
            }
        },


        copy: {
            main: {
                files: [
                    // includes files within path
                    {
                        expand: true,
                        src: ['dev/css/*.css'],
                        dest: 'static/css/',
                        flatten: true
                    }, {
                        expand: true,
                        flatten: true,
                        src: ['dev/favicon.ico'],
                        dest: 'static/'
                    }, {
                        expand: true,
                        src: ['dev/index.html'],
                        dest: 'static/',
                        flatten: true
                    }, {
                        expand: true,
                        src: ['dev/img/*'],
                        dest: 'static/img',
                        flatten: true
                    }, {
                        expand: true,
                        src: ['dev/fonts/*'],
                        dest: 'static/fonts',
                        flatten: true
                    }, {
                        expand: true,
                        src: ['dev/js/*'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/jquery/dist/jquery.min.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/bootstrap/dist/js/bootstrap.min.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/underscore/underscore-min.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/backbone/backbone.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/moment/min/moment.min.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/handlebars/handlebars.runtime.min.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/jquery-validation/dist/jquery.validate.min.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/jquery-validation/src/localization/messages_fa.js'],
                        dest: 'static/js',
                        flatten: true
                    },



                    /*
                    {
                        expand: true,
                        src: ['lib/bootstrap/dist/css/bootstrap.min.css'],
                        dest: 'static/css',
                        flatten: true
                    },
                    */
                    {
                        expand: true,
                        src: ['lib/bootstrap-rtl/dist/css/bootstrap-rtl.min.css'],
                        dest: 'static/css',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/bootstrap-persian-datetimepicker/build/css/bootstrap-datetimepicker.min.css'],
                        dest: 'static/css',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/bootstrap-persian-datetimepicker/build/js/bootstrap-persian-datetimepicker.min.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/icheck/icheck.min.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/bootbox/bootbox.js'],
                        dest: 'static/js',
                        flatten: true
                    },
                    {
                        expand: true,
                        src: ['lib/icheck/skins/flat/*'],
                        dest: 'static/css/flat',
                        flatten: true
                    }


                ]
            }
        },


        imagemin: { // Task
            dynamic: { // Another target
                files: [{
                    expand: true, // Enable dynamic expansion
                    cwd: 'static/img/', // Src matches are relative to this path
                    src: ['**/*.jpg'], // Actual patterns to match
                    dest: 'static/img/' // Destination path prefix
                }],
                options: { // Target options
                    optimizationLevel: 7
                }
            }
        },

        handlebars: { // Task
            all: { // Another target
                options: {
                    processName: function(filePath) {
                        return filePath.replace(/^dev\/templates\//, '').replace(/\.hbs$/, '');
                    }
                },
                files: {
                    'static/js/templates.js': ['dev/templates/*.hbs']
                }
            }

        },
        sprite: {
            all: {
                src: 'dev/img/sprites/*.*',
                dest: 'dev/img/spritesheet.png',
                destCss: 'dev/css/sprites.css',
                algorithm: 'binary-tree'
            }
        },
        clean: {
            build: ["lib/app/img/sprites", "lib/app/templates", "lib/app/css/sprites.css", "lib/app/js/templates.js", "lib/app/js/persianDatepicker.min.js", "lib/app/js/highstock.js", "lib/app/js/select2_locale_fa.js"]
        },
        concat_css: {
            options: {
                // Task-specific options go here.
            },
            files: {
                'lib/app/css/main.css': ['lib/app/css/select-bootstrap.css', 'persianDatepicker-default.css', 'lib/app/css/main.css']
            }
        },
        concat: {
            dist: {
                src: ['static/js/templates.js','static/js/main.js'],
                dest: 'static/js/main.js'
            }
        },
        tinypng: {
            options: {
                apiKey: "-O9ovaBsOYHH8GSuON1Pq8aPTXH1xtah",
                checkSigs: true,
                sigFile: 'dev/img/file_sigs.json',
                summarize: true,
                showProgress: true,
                stopOnImageError: true
            },
            compress: {
                expand: true,
                src: 'dev/img/*.png',
                dest: 'dev/img/',
                ext: '.png',
                flatten: true
            }
        },
        connect: {
            server: {
              options: {
                port: 8899,
                base: 'static/',
                keepalive : true
              }
            }
        },
        watch: {
            change: {
              files: ['dev/**/*'],
              tasks: ['fast']
            },
            livereload: {
              options: { livereload: true },
              files: ['static/**/*']
            }
        }


    });

    grunt.loadNpmTasks('grunt-wiredep');
    grunt.loadNpmTasks("grunt-bower-install-simple");
    grunt.loadNpmTasks('grunt-sass');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-htmlmin');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-imagemin');
    grunt.loadNpmTasks('grunt-contrib-handlebars');
    grunt.loadNpmTasks('grunt-spritesmith');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-concat-css');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-tinypng');
    grunt.loadNpmTasks('grunt-contrib-connect');
    grunt.loadNpmTasks('grunt-contrib-watch');

    // Default task(s).
    grunt.registerTask('default', ['tinypng','sass','copy', 'cssmin', 'htmlmin','imagemin', 'handlebars', 'uglify','concat']);
    grunt.registerTask('fast', ['sass','copy', 'handlebars','concat']);

};
