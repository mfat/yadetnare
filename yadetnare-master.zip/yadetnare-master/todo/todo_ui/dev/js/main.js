var API = "/api";
App = {};

$(document).ready(function() {
	window.ODate = Date;
    window.Date = pDate;

    //---------------Models----------------

	var Psudo = Backbone.Model.extend({
        urlRoot: API + '/psudo/'
    });


    var User = Backbone.Model.extend({
        urlRoot: API + '/user/'
    });

    var Task = Backbone.Model.extend({
        urlRoot: API + '/tasks/'
    });

    var Profile = Backbone.Model.extend({
        urlRoot: API + '/profile/'
    });

    var PeriodicTask = Backbone.Model.extend({
        urlRoot: API + '/periodoctasks/'
    });

    //tasks collection
    var Tasks = Backbone.Collection.extend({
        url: API + '/tasks/',
        model: Task
    });

    //Views
    var UserView = Backbone.View.extend({
        initialize: function() {
            this.model.on('change', this.changeHandle, this);
            this.model.on('error', this.errHandle, this);
            //this.render();
        },
        template: JST.user,
        render: function() {
            this.$el.html(this.template(this.model.attributes));

			if (App.tasks) {
                App.tasks.reset();
                App.tasks.fetch();
            }

            return this;
        },
        changeHandle: function() {
            if (this.model.get('msg') !== undefined) {
                this.model.clear();
            } else {
                this.render();
            }
            hideModals();
        },
        errHandle: function(model, response) {
            if (response.status == 400 || response.status == 404 || response.status == 502 || (response.responseJSON !== undefined && !response.responseJSON.message)) {
                this.model.clear();
                this.render();
                hideModals();
            } else {
                //add error in top of the modal
                $('.modal-body:visible .login_error').html(response.responseJSON.message);
                $('.modal-body:visible .login_alert').removeClass('hide');
            }
        },
        events: {
            "click a.logout": "logout"
        },
        logout: function(event) {
            this.model.clear({
                silent: true
            });
            this.model.set("id", 'logout', {
                silent: true
            });
            this.model.fetch({
                url: API + '/logout/'
            });
            return false;
        },
        login: function(form) {
            this.model.save({
                username: $(form).find('#username').val(),
                password: $(form).find('#password').val()
            }, {
                wait: true,
                url: API + '/login/'
            });
        },
        register: function(form) {
            this.model.save({
                email: $(form).find('#register_email').val(),
                password: $(form).find('#register_password').val(),
                name: $(form).find('#register_name').val()
            }, {
                wait: true,
                url: API + '/user/'
            });
        },
        el: '.user_menu'
    });


    //profile view
    ProfileView = Backbone.View.extend({
        template: JST.profile,
        initialize: function() {
            this.model.on('change', this.render, this);
            this.model.on('error', this.error, this);
        },
        render: function() {
            this.$el.html(this.template({
                profile: this.model.attributes
            }));
            $('.main').append(this.$el);
            $("#profile-form").validate();
			$("#chpass-form").validate();

            return this;
        },
        events: {
            "submit #profile-form": "changeProfile",
			"submit #chpass-form": "changePass"
        },
        changeProfile: function(event) {
			$('.alerts').html('');
			this.model.set($(event.currentTarget).serializeObject());
            this.model.save({}, {
                type: 'put',
                url: API + "/profile/0/",
				success : function(a,b,obj){
					$('.alerts').html(JST.alert({text : "پروفایل با موفقیت به روز رسانی شد",type:'success'}))
					App.user.set('profile',b);
				},
				error:function()
				{
					$('.alerts').html(JST.alert({text : "خطا در به روز رسانی پروفایل",type:'danger'}));
				}
            });
            return false;
        },
		changePass : function(event)
		{
			$('.password-alerts').html('');
			psudo = new Psudo();
			psudo.set($(event.currentTarget).serializeObject());
            psudo.save({}, {
                type: 'post',
                url: API + "/changepassword/",
				success : function(){
					$('.password-alerts').html(JST.alert({text : "رمز عبور با موفقیت تغییر کرد",type:'success'}))
				},
				error:function(model,response)
				{
					if (response.responseJSON.non_field_errors) {
						$('.password-alerts').html(JST.alert({text : "رمز ورود وارد شده اشتباه است",type:'danger'}))
					}else
					{
						$('.password-alerts').html(JST.alert({text : "خطا در به روز رسانی رمز عبور",type:'danger'}))
					}

				}
            });
			return false;
		},
        el: ''
    });

    //index page view
    IndexView = Backbone.View.extend({
        template: JST.home,
        initialize: function() {
            this.collection.on('sync', this.render, this);
            this.collection.on('error', this.render, this);
            this.collection.on('reset', this.render, this);
        },
        render: function() {
            //this.$el.html(this.template());
            //$('.main').html(this.$el.html();

            //we should sort tasks based on status
            this.collection.sort();


            this.$el.html(this.template({
                tasks: this.collection.toJSON()
            }));
            $('.main').append(this.$el);

            this.renderPicker();
            buildUI();
            return this;
        },
        renderPicker: function(defaultDate) {
            //$('#datetimepicker1').datetimepicker({defaultDate: '1394/1/1'});
            $('.date').datetimepicker({
                format: 'YYYY/MM/DD',
                showExtraDateButtons: true,
                toolbarPlacement: 'top',
                defaultDate: defaultDate
            });
            $('.time').datetimepicker({
                format: 'LT',
                showExtraTimeButtons: false,
                toolbarPlacement: 'top',
                defaultDate: defaultDate
            });
        },
        events: {
            "click .add-task": "AddTask",
            "ifChanged .icheck": "makeDone",
            "click .delete": "removeTask",
            "click .edit": "editMode",
            "click .save": "save"
        },
        AddTask: function(event) {

            if (App.user.attributes.email) {
                if ($(".more").attr("data-repeat") == '0') {
                    //normal tasks
                    task = new Task();
                    task.set('name', $('#task').val());

                    var time = $('.time').data("DateTimePicker").date();
                    var date = $('.date').data("DateTimePicker").date();

                    date.set('hour', time.get('hour'));
                    date.set('minute', time.get('minute'));
                    date.set('second', time.get('second'));

                    task.set('due_date', date.toDate().toJSON());

                    //task.set('periodic','1');

                    task.save();
                    task.on('change', function() {
                        App.tasks.fetch({
                            reset: true
                        });
                    });
                } else {
                    //periodic tasks
                    task = new PeriodicTask();
                    task.set('name', $('#task').val());

                    var time = $('.time').data("DateTimePicker").date();
                    var date = $('.date').data("DateTimePicker").date();

                    date.set('hour', time.get('hour'));
                    date.set('minute', time.get('minute'));
                    date.set('second', time.get('second'));

                    task.set('due_date', date.toDate().toJSON());

                    task.set('period', $(".more").attr("data-repeat"));

                    task.save();
                    task.on('change', function() {
                        App.tasks.fetch({
                            reset: true
                        });
                    });

                }
            } else {
                bootbox.dialog({
                    message: "برای اضافه کردن وظیفه باید وارد سیستم شوید",
                    title: "ثبت نام یا ورود به سیستم",
                    buttons: {
                        success: {
                            label: "ورود",
                            className: "btn-primary",
                            callback: function() {
                                $('.bs-login-modal-sm').modal('show');
                            }
                        },
                        danger: {
                            label: "ثبت نام",
                            className: "btn-warning",
                            callback: function() {
                                $('.bs-register-modal-sm').modal('show');
                            }
                        }
                    }
                });
            }

        },
        makeDone: function(event) {
            status = (event.currentTarget.checked) ? 'done' : 'active';
            id = $(event.currentTarget).closest('.task').data('id');
            task = this.collection.get(id);
            task.save({
                'status': status
            }, {
                url: API + "/tasks/" + id + "/"
            });
        },
        removeTask: function(event) {
            id = $(event.currentTarget).closest('.task').data('id');
            task = this.collection.get(id);


            if (task.attributes.periodic) {
                bootbox.dialog({
                    message: "موردی که تمایل به حذف آن دارید یک وظیفه تکرار شونده است. شما میتوانید تنها این مورد و یا تمام وظایف از این دست را حذف کنید. دقت کنید که این عملیات قابل بازگشت نیست",
                    title: "حذف وظیفه تکرار شونده",
                    buttons: {
                        success: {
                            label: "تنها همین وظیفه",
                            className: "btn-success",
                            callback: function() {
                                task.destroy({
                                    url: API + "/tasks/" + id + "/"
                                });
                                App.indexView.render();
                            }
                        },
                        danger: {
                            label: "تمام وظایف از این درست",
                            className: "btn-danger",
                            callback: function() {
                                task.destroy({
                                    url: API + "/periodoctasks/" + task.attributes.periodic + "/"
                                });
                                App.tasks.fetch();
                                App.indexView.render();
                            }
                        }
                    }
                });
            } else {


                bootbox.dialog({
                    message: "آیا واقعا میخواهید این وظیفه را حذف کنید ؟ این عملیات قابل بازگشت نیست",
                    title: "حذف وظیفه",
                    buttons: {
                        success: {
                            label: "بله میخواهم حذف کنم",
                            className: "btn-danger",
                            callback: function() {
                                task.destroy({
                                    url: API + "/tasks/" + id + "/"
                                });
                                App.indexView.render();
                            }
                        },
                        danger: {
                            label: "خیر",
                            className: "btn-primary",
                            callback: function() {}
                        }
                    }
                });

            }
        },
        editMode: function(event) {
            button = $(event.currentTarget);
            id = button.closest('.task').data('id');
            h2 = button.closest('.task').find('h2');

            //find task object
            task = this.collection.get(id);
            var momentDate = moment(new Date(task.attributes.due_date, false));
            //convert label to input
            h2.html("<input class='form-control' type='text' value=''>");
            h2.parent().next().html(JST.editFields());
            h2.prev().remove();
            //remove delete button
            button.next().remove();
            //change icon to ok
            button.html('<span class="glyphicon glyphicon-ok" aria-hidden="true"></span>');
            this.renderPicker(momentDate);
            h2.children().focus();
            h2.children().val(task.get('name'));
            button.removeClass('edit');
            button.addClass('save');

        },
        save: function(event) {
            button = $(event.currentTarget);
            id = button.closest('.task').data('id');
            task = this.collection.get(id);

            //set name


            var time = $('.inline-edit .time').data("DateTimePicker").date();
            var date = $('.inline-edit .date').data("DateTimePicker").date();

            date.set('hour', time.get('hour'));
            date.set('minute', time.get('minute'));
            date.set('second', time.get('second'));

            //set due date
            var name = button.closest('.task').find('h2 input').val();
            var due_date = date.toDate().toJSON();

            if (task.attributes.periodic) {
                bootbox.dialog({
                    message: "موردی که تمایل به ویرایش آن دارید یک وظیفه تکرار شونده است. شما میتوانید تنها این مورد و یا تمام وظایف از این دست را ویرایش کنید",
                    title: "ویرایش وظیفه تکرار شونده",
                    buttons: {
                        success: {
                            label: "تنها همین وظیفه",
                            className: "btn-success",
                            callback: function() {
                                task.save({
                                    'name': name,
                                    'due_date': due_date
                                }, {
                                    url: API + "/tasks/" + id + "/"
                                });
                            }
                        },
                        danger: {
                            label: "تمام وظایف از این درست",
                            className: "btn-danger",
                            callback: function() {
                                // alert("uh oh, look out!");
                                task.save({
                                    'name': name,
                                    'due_date': due_date
                                }, {
                                    url: API + "/tasks/" + id + "/"
                                });
                                task.save({
                                    'name': name,
                                    'due_date': due_date
                                }, {
                                    url: API + "/periodoctasks/" + task.attributes.periodic + "/",
                                    patch: true
                                });
                            }
                        }
                    }
                });
            } else {
                task.save({
                    'name': name,
                    'due_date': due_date
                }, {
                    url: API + "/tasks/" + id + "/"
                });

            }
        },
        el: ''
    });


    Router = Backbone.Router.extend({

        // routes configuration
        routes: {
            '(/)': 'indexPage',
            'task/:id(/)': 'taskPage',
            'profile(/)': 'profilePage'
        },
        //render Index page
        indexPage: function() {
            removeViews();
            App.tasks = new Tasks();
            App.tasks.comparator = 'status';

            App.indexView = new IndexView({
                collection: App.tasks
            });
			App.tasks.fetch();
            App.indexView.render();
        },
        profilePage: function() {
            removeViews();
            App.profile = new Profile();
            App.profileView = new ProfileView({
                model: App.profile
            });
            App.profile.fetch();
        }
    });

    var router = new Router();
    Backbone.history.start({
        pushState: true
    });

    $(document.body).on('click', ".inlink", function(e) {
        router.navigate($(this).attr('href'), {
            trigger: true
        });
        return false;
    });
    $(document).click(function() {
        $(".select").hide();
    });

    function removeViews() {
        if (App.userView === undefined) {
            App.user = new User();
            App.userView = new UserView({
                model: App.user
            });
            App.user.fetch();
        }
        if (App.indexView !== undefined) App.indexView.remove();
        if (App.profileView !== undefined) App.profileView.remove();
        return true;
    }

    //append modals
    $('.modals').html(JST.modals());
    $('#login_form').submit(function() {
        App.userView.login(this);
        return false;
    });
    $('#register_form').submit(function() {
        App.userView.register(this);
        return false;
    });

    function hideModals() {
        $('.bs-login-modal-sm').modal('hide');
        $('.bs-register-modal-sm').modal('hide');
    }

});



function digits_en2fa(number) {
    return number.toString().replace(/\d/g, function(d) {
        return String.fromCharCode(d.charCodeAt(0) + 1728);
    });
}

function pInt(s, mag) {
    return parseInt(s, mag || 10);
}

function buildUI() {
    $('.icheck').iCheck({
        checkboxClass: 'icheckbox_flat',
        radioClass: 'iradio_square',
        increaseArea: '20%' // optional
    });

    $(".more").unbind("click");
    $(".more").click(function(e) {
        e.stopPropagation();
        $(".select").toggle();
    });

    $(".select").unbind("click");
    $(".select").click(function(e) {
        e.stopPropagation();
        return false;
    });

    $(".select li").unbind("click");
    $(".select li").click(function() {
        if ($(this).attr("data-repeat") == '0') {
            $(".more").html("...");
        } else {
            $(".more").html($(this).html());
        }
        $(".select").hide();
        $(".more").attr("data-repeat", $(this).attr("data-repeat"));
    });

    $('[data-toggle="tooltip"]').tooltip();
}


Handlebars.registerHelper('shamsi', function(date) {
    jsDate = new Date(date, false);
    var shamsi = moment(jsDate);
    return shamsi.format("dddd D MMMM YYYY ساعت HH:mm");
});


Handlebars.registerHelper("ifvalue", function(conditional, options) {
    if (conditional == options.hash.equals) {
        return options.fn(this);
    } else {
        return options.inverse(this);
    }
});


// override jquery validate plugin defaults
$.validator.setDefaults({
	highlight: function(element) {
		$(element).closest('.form-group').addClass('has-error');
	},
	unhighlight: function(element) {
		$(element).closest('.form-group').removeClass('has-error');
	},
	errorElement: 'span',
	errorClass: 'help-block',
	errorPlacement: function(error, element) {
		if(element.parent('.input-group').length) {
			error.insertBefore(element.parent());
		} else {
			error.insertBefore(element);
		}
	}
});

//serializeObject
jQuery.fn.serializeObject = function() {
  var arrayData, objectData;
  arrayData = this.serializeArray();
  objectData = {};
  $.each(arrayData, function() {
    var value;
    if (this.value != null) {
      value = this.value;
    } else {
      value = '';
    }
    if (objectData[this.name] != null) {
      if (!objectData[this.name].push) {
        objectData[this.name] = [objectData[this.name]];
      }
      objectData[this.name].push(value);
    } else {
      objectData[this.name] = value;
    }
  });
return objectData;
};