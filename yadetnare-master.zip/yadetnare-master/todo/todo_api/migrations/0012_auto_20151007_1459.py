# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('todo_api', '0011_remove_periodictask_due_date'),
    ]

    operations = [
        migrations.RenameField(
            model_name='periodictask',
            old_name='last_task_due',
            new_name='due_date',
        ),
    ]
