# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings
import model_utils.fields


class Migration(migrations.Migration):

    dependencies = [
        ('todo_api', '0002_task_mail_notify_sent'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='task',
            options={'verbose_name_plural': 'tasks', 'verbose_name': 'task'},
        ),
        migrations.AlterField(
            model_name='profile',
            name='created_on',
            field=models.DateTimeField(auto_now_add=True, verbose_name='created on'),
        ),
        migrations.AlterField(
            model_name='profile',
            name='name',
            field=models.CharField(max_length=140, verbose_name='name'),
        ),
        migrations.AlterField(
            model_name='profile',
            name='updated_on',
            field=models.DateTimeField(auto_now=True, verbose_name='updated on'),
        ),
        migrations.AlterField(
            model_name='profile',
            name='user',
            field=models.OneToOneField(to=settings.AUTH_USER_MODEL, verbose_name='user'),
        ),
        migrations.AlterField(
            model_name='task',
            name='created_on',
            field=models.DateTimeField(auto_now_add=True, verbose_name='created on'),
        ),
        migrations.AlterField(
            model_name='task',
            name='due_date',
            field=models.DateTimeField(blank=True, null=True, verbose_name='due date'),
        ),
        migrations.AlterField(
            model_name='task',
            name='mail_notify_sent',
            field=models.BooleanField(default=False, verbose_name='mail notify sent'),
        ),
        migrations.AlterField(
            model_name='task',
            name='name',
            field=models.CharField(max_length=140, verbose_name='name'),
        ),
        migrations.AlterField(
            model_name='task',
            name='owner',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL, related_name='tasks', verbose_name='task creator'),
        ),
        migrations.AlterField(
            model_name='task',
            name='status',
            field=model_utils.fields.StatusField(max_length=100, no_check_for_status=True, choices=[(0, 'dummy')], default='active', verbose_name='status'),
        ),
        migrations.AlterField(
            model_name='task',
            name='updated_on',
            field=models.DateTimeField(auto_now=True, verbose_name='updated on'),
        ),
    ]
