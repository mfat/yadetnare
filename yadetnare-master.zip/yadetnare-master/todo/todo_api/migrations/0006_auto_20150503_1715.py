# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('todo_api', '0005_auto_20150503_1159'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='periodictask',
            options={'verbose_name': 'periodic task', 'verbose_name_plural': 'periodoc tasks'},
        ),
    ]
