# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('todo_api', '0008_auto_20150503_1747'),
    ]

    operations = [
        migrations.AlterField(
            model_name='periodictask',
            name='period',
            field=models.PositiveSmallIntegerField(choices=[(1, 'daily'), (2, 'weekly'), (3, 'monthly'), (4, 'yearly')], verbose_name='period'),
        ),
    ]
