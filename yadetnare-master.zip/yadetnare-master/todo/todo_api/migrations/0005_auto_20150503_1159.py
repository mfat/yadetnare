# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('todo_api', '0004_auto_20150430_1401'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='periodictask',
            name='last_task_created_on',
        ),
        migrations.AddField(
            model_name='periodictask',
            name='last_task',
            field=models.ForeignKey(to='todo_api.Task', blank=True, on_delete=django.db.models.deletion.SET_NULL, verbose_name='last task', null=True),
        ),
        migrations.AddField(
            model_name='periodictask',
            name='last_task_time',
            field=models.DateTimeField(blank=True, verbose_name='last task created on', null=True),
        ),
    ]
