# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('todo_api', '0007_periodictask_due_date'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='periodictask',
            name='last_task_time',
        ),
        migrations.AddField(
            model_name='periodictask',
            name='last_task_due',
            field=models.DateTimeField(null=True, blank=True, verbose_name='last task created on'),
        ),
    ]
