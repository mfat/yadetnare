# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import model_utils.fields
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('todo_api', '0003_auto_20150428_1437'),
    ]

    operations = [
        migrations.CreateModel(
            name='PeriodicTask',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False, auto_created=True, verbose_name='ID')),
                ('created_on', models.DateTimeField(auto_now_add=True, verbose_name='created on')),
                ('updated_on', models.DateTimeField(auto_now=True, verbose_name='updated on')),
                ('name', models.CharField(max_length=140, verbose_name='name')),
                ('period', model_utils.fields.StatusField(choices=[('daily', 'daily'), ('weekly', 'weekly'), ('monthly', 'monthly')], max_length=100, default='daily', verbose_name='period', no_check_for_status=True)),
                ('last_task_created_on', models.DateTimeField(verbose_name='last task created on')),
                ('owner', models.ForeignKey(to=settings.AUTH_USER_MODEL, related_name='periodic_tasks', verbose_name='task creator')),
            ],
            options={
                'verbose_name_plural': 'periodoc tasks',
                'verbose_name': 'periodoc task',
            },
        ),
        migrations.AddField(
            model_name='task',
            name='periodic',
            field=models.ForeignKey(to='todo_api.PeriodicTask', null=True, blank=True, verbose_name='periodic task', related_name='tasks'),
        ),
    ]
