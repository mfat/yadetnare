# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('todo_api', '0009_auto_20150518_1904'),
    ]

    operations = [
        migrations.AlterField(
            model_name='task',
            name='status',
            field=models.PositiveSmallIntegerField(verbose_name='status', choices=[(0, 'active'), (1, 'done')], default=0),
        ),
    ]
