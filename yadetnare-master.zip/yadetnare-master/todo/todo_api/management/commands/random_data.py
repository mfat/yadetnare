import os.path
from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth.models import User
from django.utils import timezone
from random import choice
from random import randint
from todo_api.models import Task

USERS_COUNT = 100
TASKS_DIFF  = 1500
TIMEDELTA = 8 * 3600

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

class Command(BaseCommand):
    help = "insert random data into database"

    def handle(self, *args, **kwargs):
        with open(BASE_DIR + "/words", "r") as words_file:
            words = words_file.readlines()
            words = [w.strip() for w in words]

        diff = USERS_COUNT - User.objects.all().count()
        print ("creating %d users" % diff)
        if diff > 0:
            users = []
            for i in range(0, diff):
                name = [choice(words) for i in range(3)]
                name = "".join(name)
                name = name[:140]
                u = User(
                    username=name,
                    email="%s@gmail.com" % name,
                    password='123'
                )
                users.append(u)
                print ("user %d created: %s" % (i, name))
            print ("saving")
            User.objects.bulk_create(users)

        todos = []
        now = timezone.now()
        user_count = 0
        for user in User.objects.all():
            user_count += 1
            diff = TASKS_DIFF - user.tasks.all().count()
            for i in range(0, diff):
                name = [choice(words) for i in range(10)]
                name = " ".join(name)
                name = name[:140]
                t = Task(
                    owner=user,
                    name=name,
                    due_date=now + timezone.timedelta(seconds=randint(0, TIMEDELTA))
                )
                todos.append(t)
                print ("task %d created for user %d" % (i, user_count))
        print ("saving")
        Task.objects.bulk_create(todos)
