from django.conf.urls import include, url
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register("tasks", views.TaskViewSet)
router.register("periodoctasks", views.PeriodicTaskViewSet)
router.register(r"user", views.UserViewSet, base_name="user-detail")
router.register(r"changepassword", views.UserChangePasswordViewSet, base_name="user-changepassword")
router.register(r"forogotpassword", views.UserForgotPasswordViewSet, base_name="user-forgotpassword")
router.register(r"resetpassword", views.UserResetPasswordViewSet, base_name="user-resetpassword")
router.register(r"profile", views.ProfileViewSet, base_name="user-profile")
router.register(r"login", views.UserLoginViewSet, base_name="user-login")
router.register(r"logout", views.UserLogoutViewSet, base_name="user-logout")

urlpatterns = [
    url(r'^', include(router.urls)),
]

from rest_framework.authtoken import views
#urlpatterns += [
#    url(r'^jwt-login/', 'rest_framework_jwt.views.obtain_jwt_token'),
#    url(r'^refresh-token/', 'rest_framework_jwt.views.refresh_jwt_token'),
#]
