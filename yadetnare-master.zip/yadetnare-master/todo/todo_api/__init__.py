
default_app_config = 'todo_api.apps.ApiConfig'
