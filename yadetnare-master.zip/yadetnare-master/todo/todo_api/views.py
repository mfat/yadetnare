from django.contrib.auth import logout
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.views import password_reset
from django.contrib.auth.views import password_reset_confirm
from django.shortcuts import render
from rest_framework import mixins
from rest_framework import permissions
from rest_framework import status
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework_jwt.serializers import JSONWebTokenSerializer
from rest_framework_jwt.views import jwt_response_payload_handler
from .models import Profile
from .models import Task
from .models import PeriodicTask
from .serializers import TaskSerializer
from .serializers import PeriodicTaskSerializer
from .serializers import UserSerializer
from .serializers import UserChangePasswordSerializer
from .serializers import UserForgotPasswordSerializer
from .serializers import UserResetPasswordSerializer
from .serializers import UserLoginSerializer
from .serializers import UserLogoutSerializer
from .serializers import ProfileSerializer


class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = [permissions.IsAuthenticated,]

    def get_queryset(self):
        return self.request.user.tasks.all()

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

    def perform_update(self, serializer):
        instance = serializer.save()
        if instance.periodic is not None and instance.status == Task.STATUS.done:
            instance.periodic.create_next()

    def perform_destroy(self, instance):
        periodic = instance.periodic
        instance.delete()
        if periodic is not None:
            periodic.create_next()


class PeriodicTaskViewSet(viewsets.ModelViewSet):
    queryset = PeriodicTask.objects.all()
    serializer_class = PeriodicTaskSerializer
    permission_classes = [permissions.IsAuthenticated,]

    def get_queryset(self):
        return self.request.user.periodic_tasks.all()

    def perform_create(self, serializer):
        instance = serializer.save(owner=self.request.user)
        instance.create_next()

    def perform_update(self, serializer):
        instance = serializer.save()
        instance.tasks.filter(status=Task.STATUS.active).update(
            name=instance.name,
        )

    def perform_destroy(self, instance):
        instance.tasks.filter(status=Task.STATUS.active).delete()
        instance.delete()


class UserViewSet(viewsets.GenericViewSet):
    serializer_class = UserSerializer

    def create(self, request, format=None):
        user = UserSerializer(data=request.data)
        if user.is_valid(raise_exception=True):
            # create user
            user_obj = user.save(username=request.data["email"])

            data = UserSerializer(user_obj).data
            request.data["username"] = request.data["email"]
            token_serializer = JSONWebTokenSerializer(data=request.data)
            if token_serializer.is_valid():
                user = token_serializer.object.get('user') or request.user
                token = token_serializer.object.get('token')
                token = jwt_response_payload_handler(token, user, request)
                data["token"] = token["token"]

            user_login = UserLoginSerializer(data=request.data, context={"request":request})
            user_login.is_valid()
            return Response(data=data, status=status.HTTP_201_CREATED)

    def list(self, request, pk=None, format=None):
        """
        returns current loggedin user
        """
        if request.user.is_authenticated():
            user = UserSerializer(request.user)
            return Response(user.data)
        return Response(status=status.HTTP_400_BAD_REQUEST)


class UserLoginViewSet(viewsets.GenericViewSet):
    """
    login user
    """
    serializer_class = UserLoginSerializer

    def create(self, request, format=None):
        user_login = UserLoginSerializer(data=request.data, context={"request":request})
        logout(request)
        if user_login.is_valid():
            return Response(UserSerializer(request.user).data)
        return Response(user_login.errors, status=status.HTTP_400_BAD_REQUEST)


class UserLogoutViewSet(viewsets.GenericViewSet):
    """
    logout user
    """
    serializer_class = UserLogoutSerializer

    def list(self, request, format=None):
        """
        logout user

        /logout
        """
        logout(request)
        return Response({"msg":"loggedout"})


class UserChangePasswordViewSet(viewsets.GenericViewSet):
    """
    change password for current user
    """
    serializer_class = UserChangePasswordSerializer

    def create(self, request, format=None):
        data = {
            "username": request.user,
            "password": request.data["old_password"],
        }
        token_serializer = JSONWebTokenSerializer(data=data)

        if token_serializer.is_valid(raise_exception=True):
            change_password = UserChangePasswordSerializer(data=request.data)
            if change_password.is_valid(raise_exception=True):
                change_password.save(username=request.user)

                data = {
                    "username": request.user,
                    "password": request.data["new_password"],
                }
                UserLoginSerializer(data=data, context={"request":request}).is_valid()

                return Response(UserSerializer(request.user).data)


class UserForgotPasswordViewSet(viewsets.GenericViewSet):
    serializer_class = UserForgotPasswordSerializer

    def create(self, request):
        forgot_serializer = UserForgotPasswordSerializer(data=request.data)
        if forgot_serializer.is_valid(raise_exception=True):
            form = PasswordResetForm({"email":request.data["email"]})
            form.is_valid()
            form.save(domain_override=request.get_host())
            return Response(data=forgot_serializer.data)


class UserResetPasswordViewSet(viewsets.GenericViewSet):
    serializer_class = UserResetPasswordSerializer

    def create(self, request):
        reset_serializer = UserResetPasswordSerializer(data=request.data)
        if reset_serializer.is_valid(raise_exception=True):
            return Response({"done":1})


class ProfileViewSet(viewsets.GenericViewSet, mixins.UpdateModelMixin):
    serializer_class = ProfileSerializer
    permission_classes = (permissions.IsAuthenticated,)

    def get_queryset(self):
        return Profile.objects.filter(user=self.request.user)

    def get_object(self):
        return Profile.objects.get(user=self.request.user)

    def list(self, request, format=None):
        return Response(ProfileSerializer(request.user.profile).data)

    def retrieve(self, request, pk=None, format=None):
        return Response(ProfileSerializer(request.user.profile).data)
