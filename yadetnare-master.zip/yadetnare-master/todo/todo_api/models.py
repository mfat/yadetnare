from dateutil.relativedelta import relativedelta
from django.utils.translation import ugettext_lazy as _
from django.conf import settings
from django.db import models
from django.utils import timezone
from model_utils import Choices
from model_utils.fields import StatusField

class BaseModel(models.Model):
    created_on = models.DateTimeField(_("created on"), auto_now_add=True)
    updated_on = models.DateTimeField(_("updated on"), auto_now=True)

    class Meta:
        abstract = True

class Task(BaseModel):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="tasks", verbose_name=_("task creator"))

    name = models.CharField(_("name"), max_length=140)

    due_date = models.DateTimeField(_("due date"), blank=True, null=True)

    STATUS = Choices(
        (0, "active", "active"),
        (1, "done", "done"),
    )
    status = models.PositiveSmallIntegerField(_("status"), choices=STATUS, default=STATUS.active)

    mail_notify_sent = models.BooleanField(_("mail notify sent"), default=False)

    periodic = models.ForeignKey(
        "PeriodicTask", verbose_name=_("periodic task"),
        blank=True, null=True,
        related_name="tasks"
    )

    class Meta:
        verbose_name = _("task")
        verbose_name_plural = _("tasks")

class PeriodicTask(BaseModel):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="periodic_tasks", verbose_name=_("task creator"))
    name = models.CharField(_("name"), max_length=140)

    PERIOD = Choices(
        (1, "daily", "daily"),
        (2, "weekly", "weekly"),
        (3, "monthly", "monthly"),
        (4, "yearly", "yearly")
    )
    period = models.PositiveSmallIntegerField(_("period"), choices=PERIOD)

    due_date = models.DateTimeField(_("last task created on"), blank=True, null=True)
    
    last_task = models.ForeignKey(
        "Task", verbose_name=_("last task"),
        blank=True, null=True,
        on_delete=models.SET_NULL
    )

    class Meta:
        verbose_name = _("periodic task")
        verbose_name_plural = _("periodoc tasks")

    def create_period(self, due):
            task = Task.objects.create(
                owner=self.owner,
                name=self.name,
                due_date=due,
                periodic=self,
            )
            self.last_task = task
            self.due_date = task.due_date
            self.save()
            return task

    def create_next(self):
        now = timezone.localtime(timezone.now())

        # if it is the first task create first instance with default due
        if self.last_task is None:
            task = self.create_period(self.due_date)
            if task.due_date < now:
                return self.create_next()
            return task

        # calculate next due
        if self.period == PeriodicTask.PERIOD.daily:
            due_date = self.due_date + relativedelta(days=1)
        elif self.period == PeriodicTask.PERIOD.weekly:
            due_date = self.due_date + relativedelta(days=7)
        elif self.period == PeriodicTask.PERIOD.monthly:
            due_date = self.due_date + relativedelta(monthes=1)
        elif self.period == PeriodicTask.PERIOD.yearly:
            due_date = self.due_date + relativedelta(years=1)

        # if last_task is active and last task is after now
        if self.last_task is not None and self.last_task.status == Task.STATUS.active and now < self.due_date:
            return self.last_task

        # if last task is deleted or done or (active but due is before now)
        task = self.create_period(due_date)
        if task.due_date < now:
            return self.create_next()
        return task

class Profile(BaseModel):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, verbose_name=_("user"))
    name = models.CharField(_("name"), max_length=140)
