import logging
from celery import shared_task
from django.conf import settings
from django.contrib.auth.models import User
from django.core.serializers import serialize
from django.utils import timezone
from django.core import serializers
from django.core import mail as dj_mail
from json import loads
from .models import Task

@shared_task
def tasks_scanner():
    mails = []
    now = timezone.now()
    for user in User.objects.all():
        tasks = user.tasks.filter(
            status=Task.STATUS.active,
            mail_notify_sent=False,
            due_date__lt=now,
        )
        #tasks = list(tasks.values_list("id", flat=True))
        if tasks.count():
            t_names = [t.name for t in tasks.all()]
            mails.append({
                "subject":"todo",
                "html_message":", ".join(t_names),
                "to":[user.email,],
            })
            tasks.update(mail_notify_sent=True)
    if len(mails):
        logging.info("sending %s mails" % len(mails))
        send_mass_html_mail.delay(mails)
        return len(mails)
    return 0

@shared_task
def periodic_scanner():
    for user in User.objects.all():
        for periodic_task in user.periodic_tasks.all():
            periodic_task.create_next()


@shared_task
def send_mass_html_mail(data_tuple):
    connection = dj_mail.get_connection()
    messages = []
    for data in data_tuple:
        mail = dj_mail.EmailMultiAlternatives(data["subject"], "", "notify@" + settings.HOSTNAME, data["to"])
        mail.attach_alternative(data["html_message"], "text/html")
        messages.append(mail)
    connection.send_messages(messages)

@shared_task
def send_html_mail(subject, to, html_message):
    if type(to) == str:
        to = [to,]
    mail = dj_mail.EmailMultiAlternatives(subject, "", "notify@" + settings.HOSTNAME, to)
    mail.attach_alternative(html_message, "text/html")
    mail.send()
