from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import ugettext_lazy as _
from .models import Profile
from .models import Task
from .models import PeriodicTask

# disable delete everywhere
admin.site.disable_action('delete_selected')
# admin settings
admin.site.site_header = _('yadetnare')
admin.site.site_title = _('administration')
admin.site.index_title = _('yadetnare')


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = (
        "owner",
        "name",
        "status",
        "due_date",
        "mail_notify_sent",
    )
    readonly_fields = (
        "created_on",
        "updated_on",
    )

    def get_readonly_fields(self, request, obj):
        if request.user.is_superuser is True:
            return self.readonly_fields
        return self.readonly_fields + self.fields

    def has_add_permission(self, request):
        return request.user.is_superuser is True

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser is True

@admin.register(PeriodicTask)
class PeriodicTaskAdmin(admin.ModelAdmin):
    list_display = (
        "owner",
        "name",
        "period",
    )
    readonly_fields = (
        "created_on",
        "updated_on",
    )

    def get_readonly_fields(self, request, obj):
        if request.user.is_superuser is True:
            return self.readonly_fields
        return self.readonly_fields + self.fields

    def has_add_permission(self, request):
        return request.user.is_superuser is True

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser is True

#@admin.register(Profile)
#class ProfileAdmin(admin.ModelAdmin):
#    list_display = [f.name for f in Task._meta.get_fields() if f.name != "id"]

# inline admin
User = get_user_model()
admin.site.unregister(User)

class PrfileInline(admin.StackedInline):
    model = Profile
    can_delete = False

    def get_readonly_fields(self, request, obj):
        if request.user.is_superuser is True:
            return self.readonly_fields
        return self.readonly_fields + self.fields

@admin.register(User)
class UserAdmin(UserAdmin):
    inlines = (PrfileInline, )

    def get_readonly_fields(self, request, obj):
        if request.user.is_superuser is True:
            return self.readonly_fields
        return self.readonly_fields + self.fields

    def has_delete_permission(self, request, obj=None):
        return False

    def has_add_permission(self, request):
        return False
