# untranslated words from other apps

from django.utils.translation import ugettext_lazy as _

_("View site")
_("Applications")
_("Fields in <strong>bold</strong> are required.")
