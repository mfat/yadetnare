from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_decode
from django.db.utils import IntegrityError
from rest_framework import serializers
from libgravatar import Gravatar
from .models import Profile
from .models import Task
from .models import PeriodicTask
from .tasks import send_html_mail


class TaskSerializer(serializers.ModelSerializer):
    status = serializers.CharField(max_length=10, min_length=2, write_only=True, required=False)

    class Meta:
        model = Task
        exclude = (
            "owner",
        )
        extra_kwargs = {
            'mail_notify_sent': {
                'read_only': True,
            },
            "periodic": {
                "read_only": True,
            },
        }

    def to_representation(self, obj):
        data = super().to_representation(obj)
        data["status"] = Task.STATUS[obj.status]
        return data

    def validate_status(self, value):
        for s in Task.STATUS:
            if s[1] == value:
                return s[0]
        raise serializers.ValidationError("Invalid status")


class PeriodicTaskSerializer(serializers.ModelSerializer):
    period = serializers.CharField(max_length=10, min_length=2, write_only=True)

    class Meta:
        model = PeriodicTask
        exclude = (
            "owner",
            "last_task",
        )

    def to_representation(self, obj):
        data = super().to_representation(obj)
        data["period"] = PeriodicTask.PERIOD[obj.period]
        return data

    def validate_period(self, value):
        found = False
        for p in PeriodicTask.PERIOD:
            if p[1] == value:
                return p[0]
        raise serializers.ValidationError("Invalid period")


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        exclude = (
            "created_on",
            "updated_on",
            "user",
            "id",
        )


class UserSerializer(serializers.ModelSerializer):
    avatar = serializers.URLField(read_only=True)
    profile = ProfileSerializer(read_only=True)
    name = serializers.CharField(max_length=140, write_only=True)
    email = serializers.EmailField(required=True)

    class Meta:
        model = get_user_model()
        fields = (
            "name",
            "email",
            "password",
            "avatar",
            "profile",
        )
        extra_kwargs = {
            'password': {
                'write_only': True
            },
        }

    def create(self, validated_data):
        user = get_user_model().objects.create_user(
            validated_data["username"],
            validated_data["email"],
            validated_data["password"],
        )
        Profile.objects.create(
            user=user,
            name=validated_data["name"],
        )
        send_html_mail.delay("register", validated_data["email"], "welcome %s" % validated_data["email"])
        return user

    def to_representation(self, obj):
        data = super().to_representation(obj)
        try:
            data["avatar"] = Gravatar(obj.email).get_image(size=100, default="retro", rating="x")
        except AttributeError:
            data["avatar"] = Gravatar(obj["email"]).get_image(size=100, default="retro", rating="x")

        if data["profile"] is None:
            Profile.objects.create(
                user=get_user_model().objects.get(id=obj.id),
                name=obj.email,
            )

        return data

    def validate_name(self, value):
        value = value.strip()
        if len(value):
            return value
        raise serializers.ValidationError("invalid name")

    def validate_email(self, value):
        try:
            get_user_model().objects.get(email=value)
            raise serializers.ValidationError("user already exists")
        except get_user_model().DoesNotExist:
            return value


class UserLoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=30)
    password = serializers.CharField(max_length=128, min_length=1)

    class Meta:
        pass

    def validate(self, data):
        user = authenticate(username=data["username"], password=data["password"])
        if user is not None:
            if user.is_active:
                request = self.context['request']
                login(request, user)
                return data
            raise serializers.ValidationError("user is not active")
        raise serializers.ValidationError("wrong username/password")


class UserLogoutSerializer(serializers.Serializer):
    pass


class UserChangePasswordSerializer(serializers.Serializer):
    new_password = serializers.CharField(max_length=128, min_length=1)
    re_new_password = serializers.CharField(max_length=128, min_length=1)
    old_password = serializers.CharField(max_length=128)

    def create(self, validated_data):
        username = validated_data["username"]
        user = get_user_model().objects.get(username__exact=username)
        user.set_password(validated_data["new_password"])
        user.save()
        return user

    def validate(self, data):
        if data["new_password"] != data["re_new_password"]:
            raise serializers.ValidationError("new password and repeat password is not the same")
        return data

class UserForgotPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField(max_length=140)


class UserResetPasswordSerializer(serializers.Serializer):
    id = serializers.CharField(min_length=1)
    token = serializers.CharField(min_length=1)
    new_password1 = serializers.CharField(min_length=1)
    new_password2 = serializers.CharField(min_length=1)

    def validate(self, data):
        try:
            id = urlsafe_base64_decode(data["id"]).decode("utf-8")
            user = get_user_model().objects.get(id=id)
        except ValueError:
            raise serializers.ValidationError("invalid id")
        except get_user_model().DoesNotExist:
            raise serializers.ValidationError("invalid id+")

        if not default_token_generator.check_token(user, data["token"]):
            raise serializers.ValidationError("invalid token")

        form = SetPasswordForm(
            user,
            {
                "new_password1": data["new_password1"],
                "new_password2": data["new_password2"],
            }
        )
        if form.is_valid():
            form.save()
        else:
            raise serializers.ValidationError(list(form.error_messages.keys()))
        return data
