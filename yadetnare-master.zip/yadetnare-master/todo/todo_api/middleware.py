from django.conf import settings

class AddCsrfTokenToHeader:
    def process_request(self, request):
        csrftoken = request.COOKIES.get(settings.CSRF_COOKIE_NAME)
        if csrftoken is not None and request.META.get("HTTP_X_CSRFTOKEN") is None:
            request.META["HTTP_X_CSRFTOKEN"] = csrftoken
        setattr(request, '_dont_enforce_csrf_checks', True)
