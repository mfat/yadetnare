import os
from .settings import *

DEBUG = False
TEMPLATE_DEBUG = False

ALLOWED_HOSTS = (
    "127.0.0.1",
    "yadetnare.ir",
    "www.yadetnare.ir",
    "192.3.45.138",
)

HOSTNAME =  "yadetnare.ir"

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_jwt.authentication.JSONWebTokenAuthentication',
        'rest_framework.authentication.SessionAuthentication',
    ),
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    )
}

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'file': {
            'level': 'DEBUG',
            'class': 'logging.FileHandler',
            'filename': BASE_DIR + '/debug.log',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['file'],
            'level': 'DEBUG',
            'propagate': True,
        },
    },
}

import datetime
CELERYBEAT_SCHEDULE = {
    'tasks_scanner': {
        'task': 'todo_api.tasks.tasks_scanner',
        #'schedule': datetime.timedelta(seconds=5),
        'schedule': datetime.timedelta(seconds=60),
        'args': (),
    },
    'periodic_scanner': {
        'task': 'todo_api.tasks.periodic_scanner',
        'schedule': datetime.timedelta(hours=1),
        'args': (),
    },
}

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'todo',
        'USER': 'root',
        'PASSWORD': 'AgileYadetNare',
        'HOST': 'localhost',   # Or an IP Address that your DB is hosted on
        'PORT': '3306',
    }
}
