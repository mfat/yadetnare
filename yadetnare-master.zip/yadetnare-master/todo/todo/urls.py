from django.conf.urls import include, url
from django.contrib import admin

urlpatterns = [
    # Examples:
    # url(r'^$', 'todo.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r"^api/", include("todo_api.urls")),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    url(r'^docs/', include('rest_framework_swagger.urls')),
]

# serve stupid static files
# only for debug mode
from django.contrib.staticfiles import views
from django.http import Http404

def password_reset_confirm(request, uidb64=None, token=None):
    return views.serve(request, "index.html")
def serve(request, path=None):
    try:
        return views.serve(request, path)
    except Http404:
        if "." in path:
            raise
        if path.startswith("api"):
            raise
        if path.startswith("admin"):
            raise
        return views.serve(request, "index.html")

urlpatterns += (
    url(r'^passwordreset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
        password_reset_confirm,
        name='password_reset_confirm'
    ),
    url(r'(?P<path>.*)$', serve)
)
