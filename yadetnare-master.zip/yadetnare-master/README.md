# todo

## production

run api and server:

    ./tasks.sh deploy_site

run celery daemon:

    ./tasks.sh deploy_celery

collect static files:

    ./tasks.sh collectstatic

## development

development env

    ./tasks.sh run_site
    ./tasks.sh run_celery

## server

```
$ ssh yadetnare@yadetnare.ir
Password: AgileYadetNare

mysql
user: root
pass: AgileYadetNare
```
